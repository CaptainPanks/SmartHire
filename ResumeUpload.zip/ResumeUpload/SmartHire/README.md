# SmartHire
Lightweight simple recruiting suite
