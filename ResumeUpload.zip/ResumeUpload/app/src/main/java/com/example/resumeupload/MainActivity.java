package com.example.resumeupload;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    final static private String APP_KEY = "7c69nc21asug1gt";
    final static private String APP_SECRET = "14psqhkzh3qgzfd";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }


    public void EmployerActivity(View view)
    {
        Intent intent = new Intent(this, EmployerPage.class);
        startActivity(intent);

    }

    public void ApplicantActivity(View view)
    {
        Intent intent = new Intent(this, ApplicantLogin.class);
        startActivity(intent);

    }
}
